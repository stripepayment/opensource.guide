// +build !windows

package iostreams

func (s *IOStreams) EnableVirtualTerminalProcessing() {}
